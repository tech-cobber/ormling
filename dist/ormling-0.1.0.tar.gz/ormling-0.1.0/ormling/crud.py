from .schema import Attribute
from typing import List


def create_sql(name: str, attributes: List[Attribute]):
    query = f"CREATE TABLE {name}(\n"
    for attr in attributes[:-1:]:
        query += f"    {attr},\n"
    return query + f"    {attributes[-1]}\n)"
